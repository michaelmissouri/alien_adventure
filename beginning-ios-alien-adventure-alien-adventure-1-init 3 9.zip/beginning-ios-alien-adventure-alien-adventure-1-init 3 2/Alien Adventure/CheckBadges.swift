//
//  CheckBadges.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 10/4/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func checkBadges(var badges: [Badge], requestTypes: [UDRequestType]) -> Bool {
            
        for badge in badges {
            if requestTypes.contains(badge.requestType) {
                let badgeIndex = badges.indexOf(badge)
                badges.removeAtIndex(badgeIndex!)
                print("Match")
                print(badges.count)
            }
        }

        if requestTypes.count == badges.count {
            print("Equal Count")
            return false
        } else {
            print("Not equal, Good News")
            return true
        }
    }
}
