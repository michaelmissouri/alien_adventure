//
//  PlanetData.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 10/4/15.
//  Copyright © 2015 Udacity. All rights reserved.
//
import Foundation

extension Hero {
    
    func planetData(dataFile: String) -> String {
        
        let planetInfo = NSBundle.mainBundle().URLForResource("PlanetData", withExtension: "json")
        let rawPlanetsJSON = NSData(contentsOfURL: planetInfo!)
        
        let planetDictFromJSON: [[String: AnyObject]]
        do {
            planetDictFromJSON = try! NSJSONSerialization.JSONObjectWithData(rawPlanetsJSON!, options: []) as! [[String: AnyObject]]
        }
        
        var planetNames = String()
        
        var commonCount = 0
        
        var uncommonCount = 0
        
        var rareCount = 0
        
        var legendaryCount = 0
        
        var totalCount = 0
        
//        var planetOne = planetDictFromJSON[0]
        
        for planet in planetDictFromJSON {
            
            if let name = planet["Name"] as? String {
                planetNames = name
        
                if let commonFound = planet["CommonItemsDetected"] as? Int {
                    commonCount = commonFound
                    totalCount += commonCount
                }
                if let uncommon = planet["UncommonItemsDetected"] as? Int {
                    uncommonCount = uncommon * 2
                    totalCount += uncommonCount
                }
                if let rareItems = planet["RareItemsDetected"] as? Int {
                    rareCount = rareItems * 3
                    totalCount += rareCount
                }
                if let legendaryItems = planet["LegendaryItemsDetected"] as? Int {
                    legendaryCount = legendaryItems * 4
                    totalCount += legendaryCount
                }
            
            }
        }
        return planetNames
    }
    
}

// If you have completed this function and it is working correctly, feel free to skip this part of the adventure by opening the "Under the Hood" folder, and making the following change in Settings.swift: x