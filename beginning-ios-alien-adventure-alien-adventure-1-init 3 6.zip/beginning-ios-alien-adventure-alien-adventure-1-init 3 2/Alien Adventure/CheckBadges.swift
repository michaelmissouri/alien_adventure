//
//  CheckBadges.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 10/4/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func checkBadges(badges: [Badge], requestTypes: [UDRequestType]) -> Bool {
        var result = true
        var badgesCopy = badges
        for request in requestTypes {
            for i in badgesCopy.indices {
                if badgesCopy[i].requestType != request {
                    result = false
                    badgesCopy.removeAtIndex(i)
                    print(badgesCopy)
                    break
                } else {
                    result = true
                }
            }
            
        }
        return result
    }
    
}