//
//  CheckBadges.swift
//  Alien Adventure
//
//  Created by Jarrod Parkes on 10/4/15.
//  Copyright © 2015 Udacity. All rights reserved.
//

extension Hero {
    
    func checkBadges(var badges: [Badge], requestTypes: [UDRequestType]) -> Bool {
        
        var endResult = true
        
        let badgeRequest = requestTypes
        
        print(badgeRequest)
        
        for _ in requestTypes {
        
            if badgeRequest.count != badges.count {
                for item in badges.indices {
                    badges.removeAtIndex(item)
                    endResult = false
                    break
                }
                
            }
                else {
                    endResult = true
                
            }
        }
    return endResult
    }
    

}
